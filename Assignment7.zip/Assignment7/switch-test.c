void main() {
    int i;
    i = 0;
    int j;

    switch (i) {
   	    case 0: { j = 0; }
   	    case 1: { j = 1; }
    }

    print j;
}

void main() {
  int i;
  i = 0;

  print ++i;
  println;

  print ++i;
  println;

  print --i;
  println;

  print --i;
  println;
}

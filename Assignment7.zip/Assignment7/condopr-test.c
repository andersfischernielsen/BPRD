void main() {
  int i;
  int j;
  j = 0;

  i = j ? i = 2 : i = 1;
  j = 1;
  
  i = j ? i = 2 : i = 1;
}

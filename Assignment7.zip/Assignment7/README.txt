//Assignment5

//8.1
See "structured-bytecode-ex3.txt", "structured-bytecode-ex5.txt" and "ex3trace.txt" for solutions.

//8.3
See "MicroC/Comp.fs", "MicroC/CLex.fsl", "MicroC/CPar.fsy" and "preinc-predec-test.c" for solution.

//8.4
See "structured-bytecode-ex8.txt" and "structured-bytecode-ex13.txt" for solutions.

//8.5
See "MicroC/Absyn.fs", "MicroC/CLex.fsl", "MicroC/CPar.fsy", "MicroC/Interp.fs", "MicroC/Comp.fs" and "condopr-test.c" for solution.

//8.6
See "MicroC/Absyn.fs", "MicroC/CLex.fsl", "MicroC/CPar.fsy", "MicroC/Interp.fs", "MicroC/Comp.fs" and "switch-test.c" for solution.
Solution to this execise might be wrong. I've commented in Comp.fs in "cStmt" what I'm trying to accomplish. 
Comments whether this is correct/is the right direction to go are MORE than welcome. :) 